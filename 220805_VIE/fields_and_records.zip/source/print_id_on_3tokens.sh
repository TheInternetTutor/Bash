
#-----------------------------------------------------------------------
function print_id_on_3tokens()
{
  local tokens=(${@}); # create array!
  local -i d1 d2 d3;
  local -l randint id;
  let d1="${RANDOM}%10";
  let d2="${RANDOM}%10";
  let d3="{RANDOM}%10";
  randint=${d1}${d2}${d3}${d3};

  if [ -z "${tokens[0]}" ]; then {
    tokens[0]='?';
    tokens[1]='?';
    tokens[2]='?';
  }
  elif [ -z "${tokens[1]}" ]; then {
    tokens[1]='?';
    tokens[2]='?';
  }
  # if 3rd element is empty, swap it with 2nd and make 2nd 'X'
  elif [ -z "${tokens[2]}" ]; then {
    tokens[2]=${tokens[1]};
    tokens[1]='*';
  }
  fi

  id="${tokens[0]:0:1}${tokens[1]:0:1}${tokens[1]:0:1}${randint}";
  # email=${id}"@k12.edu";
  echo ${id}; #${email};
  return 0;
} # print_id_on_3tokens.end
