
#-----------------------------------------------------------------------
# DEFINE SOME USEFULL ALIASES:

# prints a line of dashes to separate ouput
alias pl72="echo -en {1..72}'-' | tr -d ' [0-9]'";

# same as before, but print a new line at the end
alias pl72n='pl72; echo';

# provide numbered lines
alias nltr="$(cat <<< '
nl --body-numbering=a --number-format=rz --number-width=3 | tr "\t" " "
' | fmt -w 2222)";

# prints tokens (words) in colunms 10 row and 6 columns
alias print_tokens_10x6=$(cat <<-'fin'
awk '{
  printf "%-12s", $1;
  if( NR % 6 == 0){ print ""'' }
}' | head -n 10
fin
);
# print_tokens_10x6 could(should?) be a function (==> more flexible)

# print a separation line, date, path, size, word count, etc.
alias print_script_info='
echo {1..72}"x" | tr -d " [:digit:]";
date +"%X/%a/%d/%m/%y";
# echo ${PWD};
script=${BASH_SOURCE[0]};
script=${script/${PWD}/"."};
echo ${script};
# echo ${script}-$(date +"%X/%a/%d/%m/%y");
# ls -lg ${script};
# wc ${script};
# grep -e "^source[[:space:]]" ${script};
echo {1..72}"x" | tr -d " [:digit:]";
:';

# keep a log of outputs for "main.sh"
function log_output()
{
  output=./$(date +"%s")_vie.txt;
  {
    echo -e {1..72}"#" | tr -d " [0-9]";
    date;
    source main.sh;
    echo -e "\n\n\n";
  } >> ${output} 2>&1;
  cat ${output} | nltr;
  ls *_vie.txt --color --group-directories-first -g \
  --no-group --file-type;
  return 0;
}

lgl='
{ 
  if (length($0) > max) { 
    max = length($0);
    record=$0; 
    nr=NR; 
  } 
} 
END { 
  # print nr;
  # print max; 
  # print "[%-"max"s]"; 
  print record "\n" nr  " | " max; 
}';
alias lgl='awk "${lgl}" '

