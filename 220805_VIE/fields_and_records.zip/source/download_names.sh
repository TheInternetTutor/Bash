#!/bin/bash

# array of URL's to websites containing data about names
declare -a URL_FNAMES=(
'https://namecensus.com/first-names/common-male-first-names/'
'https://namecensus.com/first-names/common-male-first-names/?start=300'
'https://namecensus.com/first-names/common-male-first-names/?start=600'
'https://namecensus.com/first-names/common-male-first-names/?start=900'
'https://namecensus.com/first-names/common-female-first-names/'
'https://namecensus.com/first-names/common-female-first-names/?start=1000'
'https://namecensus.com/first-names/common-female-first-names/?start=2000'
'https://namecensus.com/first-names/common-female-first-names/?start=3000'
# 'https://www.rong-chang.com/namesdict/popular_names.htm'
);
declare fl="${PATH_MAIN_SCRIPT}/data/names.htm";
fl=${fl/${PWD}/.}; # relative path

mkdir -p "${PATH_MAIN_SCRIPT}/data/";

if [ ! -f ${fl} ]; then {
  echo -n "Downloading  .... : ";
  # wget is good ... but curl is more flexible!
  curl --silent ${URL_FNAMES[@]} > ${fl};
  # wget --output-document=- --quiet ${URL_FNAMES[@]} > ${fl};
} else {
  echo -n "Already Downloaded: ";
} fi
echo ${fl};
