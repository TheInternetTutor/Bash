
#-----------------------------------------------------------------------
function get_int_within_range()
{
  local -i min=${1:-1};
  local -i max=${2:-100};
  local name_var=${3:-GET_INT_WITHIN_RANGE};
  local -i range="max - min";
  local -i intg="${RANDOM} % (range + 1) + min";
  eval ${name_var}=${intg};
  # declare -p intg ${name_var};
  return 0;
} # get_int_within_range.end

#-----------------------------------------------------------------------
# https://www.researchgate.net/figure/Age-distribution-of-students-enrolled-in-the-distance-learning-courses_fig1_5765091
function print_random_dob()
{
  local -i seconds_in_year='365*24*30*30';
  local today=$(date +'%Y/%m/%d'); #------------------------- 1
  local -i today_epoch=$(date --date=${today} +'%s'); #------ 2

  local -i int_1_100=0;
  local -i random_date;
  local fmt='%3s | %4s | %2s | ';

  let int_1_100="${RANDOM} % 100 + 1"; # a number in range [1, 100]
  case ${int_1_100} in
  [1-9] | [123][0-9] | 4[012]) # 42%: numbers in range [1, 42]
  {
    probability='42%';
    get_int_within_range 18 25 age;
  };;
  _____) # 36%: numbers in range [43, 78]
  {
    probability='__%';
    get_int_within_range 26 35 age;
  };;
  _____) # 22%: numbers in range [79, 100]
  {
    probability='__%';
    get_int_within_range 35 80 age;
  };;
  esac
  let random_date='today_epoch - age*seconds_in_year';
  # randomize the birth month
  let random_date-="(${RANDOM}*99999999) % seconds_in_year";

  printf "${fmt}" ${int_1_100} ${probability} ${age};
  eval date --date="@${random_date}" +'%Y/%X/d';

  # declare -p today today_epoch random_date;
  # declare -p years_back_18 years_back_25 years_back_35 years_back_80;
  return 0;
} # print_random_dob.end
