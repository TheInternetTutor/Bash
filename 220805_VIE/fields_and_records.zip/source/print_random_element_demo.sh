#!/bin/bash
print_script_info;

source aliases_functions.sh;
source print_random_element.sh;

#-----------------------------------------------------------------------
pl72n;

fname=$(print_random_element FIRST_NAME);
lname=$(print_random_element LAST_NAME);
echo ${lname}, ${fname};
fname=$(print_random_element FIRST_NAME);
lname=$(print_random_element LAST_NAME);
echo ${lname}, ${fname};
fname=$(print_random_element FIRST_NAME);
lname=$(print_random_element LAST_NAME);
echo ${lname}, ${fname};
fname=$(print_random_element FIRST_NAME);
lname=$(print_random_element LAST_NAME);
echo ${lname}, ${fname};
fname=$(print_random_element FIRST_NAME);
lname=$(print_random_element LAST_NAME);
echo ${lname}, ${fname};

