
source print_random_element.sh;

#-----------------------------------------------------------------------
function print_random_2nd_name()
{
  local -i rand_int_1_100=0;
  local fmt='%3s | %-15s';
  fname=$(print_random_element FIRST_NAME);

  let rand_int_1_100="${RANDOM} % 100 + 1"; # a number in range [1, 100]
  # printf "%3s |" ${rand_int_1_100}; # [*DBG*]
  case ${rand_int_1_100} in
  [1-9] | [1-4][0-9] | 50) # 50%: numbers in range [1-50]
  {
    :
    # echo -n "50% |"; # [*DBG*]
  };;
  5[1-9] | [67][0-9] | 8[0-5]) # 35%: numbers in range [51-85]
  {
    fname=${fname:0:1}.;
    # echo -n "35% |"; # [*DBG*]
  };;
  8[6-9] | 9[0-9] | 100) # 15%: numbers in range [86-100]
  {
    fname="";
    # echo -n "15% |"; # [*DBG*]
  };;
  esac
  echo -n ${fname};

  return 0;
} # print_random_2nd_name.end
