
#-----------------------------------------------------------------------
# https://www.ssa.gov/kc/SSAFactSheet--IssuingSSNs.pdf
# SSA will not issue SSNs beginning with the number "9".
# SSA will not issue SSNs beginning with the number "666" @ postn 1-3.
# SSA will not issue SSNs beginning with the number "000" @ postn 1-3.
# SSA will not issue SSNs with the number "00" @ postn 4-5.
# SSA will not issue SSNs with the number "0000" @ postn 6-9.
function print_random_ssn()
{
  local -i random_int=0;
  local ssn;

  ssn=$({
    # ... not beginning with the number "9".
    # ... not beginning with the number "666" @ postn 1-3.
    # ... not beginning with the number "000" @ postn 1-3.
    let random_int="${RANDOM} % 898 + 1";
    echo {001..665} {667..899} | fmt -w1 | sed -n "${random_int}p";

    # ... not with the number "00" @ postn 4-5.
    let random_int="${RANDOM} % 99 + 1";
    echo {01..99} | fmt -w1 | sed -n "${random_int}p";

    # ...  not with the number "0000" @ postn 6-9.
    echo XXXX;

  } | fmt -w50 | tr -d ' ');
  echo ${ssn:0:3}-${ssn:3:2}-${ssn:5:100};

  return 0;
} # print_random_ssn.end

#-----------------------------------------------------------------------
function print_n_random_ssn()
{
  local qtt=${1:-3};
  for ssn in $(eval echo {1..${qtt}}); do {
    print_random_ssn; 
  } done | sort | uniq;
  return 0;
} # print_n_random_ssn.end

