
#-----------------------------------------------------------------------
function print_webpage_capitalized_words() 
{
  # declare variable locally so they will be unset at end of function
  local fl_webpage=${1:-1_FL_WEBPAGE};
  local fl_webpage;
  
  cat ${fl_webpage} \
  | sed --expression='s/<[^>]*>//g' \
  | fmt --width=1 \
  | sort | uniq \
  | grep --regexp='^[A-Z].*$' \
  | grep --invert-match --regexp='[.,/;(){}:?!”]' \
  | grep --invert-match --regexp='^.$' \
  | grep --regexp='[AEIOUYaeiouy]' \
  | grep --regexp='^[A-Z][A-Z]*$' \
  ;
  # | grep -v '^[^AEIOUYaeiouy]$' \
  return 0;
} # print_webpage_capitalized_words.end 

#-----------------------------------------------------------------------
# Some times a single call will NOT get all the entries from the
# web page! Executing the same command several times while appending
# increases the probability of getting all entries.
function print_webpage_capitalized_words_N()
{
  local fl_webpage=${1:-1_NAME_OF_ARRAY_URLS};
  local tmp_file='/tmp/2208202351.txt';# overwritten on every run!

  print_webpage_capitalized_words ${fl_webpage} >  ${tmp_file};
  print_webpage_capitalized_words ${fl_webpage} >> ${tmp_file};
  # sort ${tmp_file} | uniq > ${tmp_file};# file too large?
  print_webpage_capitalized_words ${fl_webpage} >> ${tmp_file};
  print_webpage_capitalized_words ${fl_webpage} >> ${tmp_file};
  print_webpage_capitalized_words ${fl_webpage} >> ${tmp_file};
  print_webpage_capitalized_words ${fl_webpage} >> ${tmp_file};
  sort ${tmp_file} | uniq > ${tmp_file};

  cat ${tmp_file};
  # wc ${tmp_file} > /dev/stderr;
  return 0;
} # print_webpage_capitalized_words_N.end

