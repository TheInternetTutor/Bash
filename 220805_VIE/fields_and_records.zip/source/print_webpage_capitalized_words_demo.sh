#!/bin/bash
print_script_info;

source aliases_functions.sh;
source print_webpage_capitalized_words.sh; 

declare fl_names_htm="${PATH_MAIN_SCRIPT}/data/names.htm";
declare fl_names_txt="${PATH_MAIN_SCRIPT}/data/names.txt";
declare fl_surnames_htm="${PATH_MAIN_SCRIPT}/data/surnames.htm";
declare fl_surnames_txt="${PATH_MAIN_SCRIPT}/data/surnames.txt";

# shorten paths by making them relative
fl_names_htm=${fl_names_htm/${PWD}/.};
fl_names_txt=${fl_names_txt/${PWD}/.};
fl_surnames_htm=${fl_surnames_htm/${PWD}/.};
fl_surnames_txt=${fl_surnames_txt/${PWD}/.};

# sec. 1 >>>
#-----------------------------------------------------------------------
pl72n;
print_webpage_capitalized_words ${fl_names_htm} | print_tokens_10x6;
pl72n;
# if the document containing names does NOT exist, then create it
if [ ! -f ${fl_names_txt} ]; then {
  print_webpage_capitalized_words_N ${fl_names_htm} > ${fl_names_txt};
} fi
head -n 5 ${fl_names_txt};
# <<< sec. 1

# Copy/paste the code in section 1 (between "sec. 1 >>> # <<< sec. 1")
# just below it (replacing these comment lines). Edit the pasted code
# accordingly so it will extract all the last names from the web page
# "surnames.htm".

#-----------------------------------------------------------------------
pl72n;
wc ${fl_names_txt};
