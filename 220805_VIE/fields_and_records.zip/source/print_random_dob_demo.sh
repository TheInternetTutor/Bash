#!/bin/bash
print_script_info;

source aliases_functions.sh;
source print_random_dob.sh;

#-----------------------------------------------------------------------
pl72n;
for i in {1..10}; do { 
  print_random_dob; 
} done | sort -n;
