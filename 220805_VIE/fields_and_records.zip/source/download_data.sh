#!/bin/bash
print_script_info;

source aliases_functions.sh;

#-----------------------------------------------------------------------
pl72n;
source download_names.sh;
source download_surnames.sh;
source download_zipcodes.sh;
