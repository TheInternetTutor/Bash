
#-----------------------------------------------------------------------
function print_random_element()
{
  local -a name_of_array=${1:-1_NAME_OF_ARRAY};
  local -i lg=0;
  local -i random_index=0;

  eval "lg=\${#${name_of_array}[@]}"; # get the length of the array
  # get a random integer in the range [0, length of array)
  random_index=${RANDOM}%${lg}; 
  eval "echo -n \${${name_of_array}[${random_index}]}";
  # declare -p lg;
  
  return 0;
} # print_random_element.end

