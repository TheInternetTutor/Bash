#!/bin/bash

# array of URL's to websites containing data about surnames
declare -a URL_LNAMES=(



# *** PASTE WEBSITES ADDRESSES HERE ***
# One per line and within apostrophes 




);
declare fl="${PATH_MAIN_SCRIPT}/data/surnames.htm";
fl=${fl/${PWD}/.}; # relative path

mkdir -p "${PATH_MAIN_SCRIPT}/data/";# create destination directory

if [ ! -f ${fl} ]; then {
  echo -n "*** NOT Downloaded: ";



} else {
  echo -n "Already Downloaded: ";
} fi
echo ${fl};
