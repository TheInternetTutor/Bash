#!/bin/bash
print_script_info;

source aliases_functions.sh;
source print_random_ssn.sh;

#-----------------------------------------------------------------------
pl72n;
print_random_ssn;
print_random_ssn;
print_random_ssn;

fl_ssn=${PATH_MAIN_SCRIPT}/data/ssn.txt;
fl_ssn=${fl_ssn/${PWD}/.};

# if the document "ssn.txt" does NOT exist, then create it
# if [ ! -e ${fl_ssn} ]; then 
({
  print_n_random_ssn 10 >> ${fl_ssn};
  sort ${fl_ssn} | uniq > ${fl_ssn};
} &) # ({ } &) makes the job run silently in background!
# fi

echo;
fmt -w65 ${fl_ssn} | head -n 10;

echo -e "\nWord count:";
wc ${fl_ssn};
