#!/bin/bash
print_script_info;

source aliases_functions.sh;
source print_random_2nd_name_debug.sh;

#-----------------------------------------------------------------------
pl72n;

print_random_2nd_name; echo;
print_random_2nd_name; echo;
print_random_2nd_name; echo;
print_random_2nd_name; echo;
print_random_2nd_name; echo;

print_random_2nd_name; echo;
print_random_2nd_name; echo;
print_random_2nd_name; echo;
print_random_2nd_name; echo;
print_random_2nd_name; echo;
