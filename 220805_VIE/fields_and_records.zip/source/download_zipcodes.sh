#!/bin/bash

# array of URL's containing zipcodes data
declare -a URL_ZIPCODE=(
'http://federalgovernmentzipcodes.us/free-zipcode-database-Primary.csv'
);
declare fl="${PATH_MAIN_SCRIPT}/data/zipcodes.csv";
fl=${fl/${PWD}/.}; # relative path

mkdir -p "${PATH_MAIN_SCRIPT}/data/";# create destination directory

if [ ! -f ${fl} ]; then {
  echo -n "Downloading  .... : ";
  curl --silent ${URL_ZIPCODE[@]}  > ${fl};
} else {
  echo -n "Already Downloaded: ";
} fi
echo ${fl};
