#!/bin/bash
print_script_info;

source aliases_functions.sh;
source print_random_element.sh;
source print_random_2nd_name.sh;
source print_id_on_3tokens.sh;

#-----------------------------------------------------------------------
pl72n;
fname=$(print_random_element FIRST_NAME);
sname=$(print_random_2nd_name);
lname=$(print_random_element LAST_NAME);
echo ${fname} ${sname} ${lname};
print_id_on_3tokens;
print_id_on_3tokens ${fname};
print_id_on_3tokens ${fname} ${lname};
print_id_on_3tokens ${fname} ${sname} ${lname};
print_id_on_3tokens "${fname} ${sname} ${lname}";

#-----------------------------------------------------------------------
pl72n;
declare fmt id;
fmt="%-13s %-13s %-17s %-8s %-18s\n"

printf "${fmt}" FIRST_NAME SECOND_NAME LAST_NAME ID EMAIL;
fname=$(print_random_element FIRST_NAME);
sname=$(print_random_2nd_name);
lname=$(print_random_element LAST_NAME);
id=$(print_id_on_3tokens  ${fname} "${sname}" ${lname});
printf "${fmt}" ${fname} "${sname}" ${lname} ${id} ${id}@k12.edu;

fname=$(print_random_element FIRST_NAME);
sname=$(print_random_2nd_name);
lname=$(print_random_element LAST_NAME);
id=$(print_id_on_3tokens  ${fname} "${sname}" ${lname});
printf "${fmt}" ${fname} "${sname}" ${lname} ${id} ${id}@k12.edu;

fname=$(print_random_element FIRST_NAME);
sname=$(print_random_2nd_name);
lname=$(print_random_element LAST_NAME);
id=$(print_id_on_3tokens  ${fname} "${sname}" ${lname});
printf "${fmt}" ${fname} "${sname}" ${lname} ${id} ${id}@k12.edu;

fname=$(print_random_element FIRST_NAME);
sname=$(print_random_2nd_name);
lname=$(print_random_element LAST_NAME);
id=$(print_id_on_3tokens  ${fname} "${sname}" ${lname});
printf "${fmt}" ${fname} "${sname}" ${lname} ${id} ${id}@k12.edu;

fname=$(print_random_element FIRST_NAME);
sname=$(print_random_2nd_name);
lname=$(print_random_element LAST_NAME);
id=$(print_id_on_3tokens  ${fname} "${sname}" ${lname});
printf "${fmt}" ${fname} "${sname}" ${lname} ${id} ${id}@k12.edu;
