
#-----------------------------------------------------------------------
function fill_up_arrays_from_file()
{
  local path_to_file=${1:-1_PATH_TO_FILE};
  local -a name_of_array=${2:-2_NAME_OF_ARRAY};
  local var_exists=false;
  local rtn=1;

  # var_exists = true if the name of the array exist in main scope
  declare -p ${name_of_array} 2> /dev/null 1>&2 && var_exists=true;
  
  if [ -e ${path_to_file} ] && [ "${var_exists}" = true ]; then {
    eval "${name_of_array}=(\$(fmt -w999 ${path_to_file}))";
    rtn=0;
  } 
  elif [ ! -e ${path_to_file} ]; then {
    echo -en "\n*** PATH NOT FOUND: ${path_to_file}" >> /dev/stderr;
  } 
  else {
    echo -en "\n*** VARIABLE NOT FOUND: ${name_of_array}" >> /dev/stderr;  
  } fi

  return ${rtn};
} # fill_up_arrays_from_file.end

