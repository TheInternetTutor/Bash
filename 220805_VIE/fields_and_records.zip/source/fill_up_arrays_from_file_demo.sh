#!/bin/bash
print_script_info;

source aliases_functions.sh;
source fill_up_arrays_from_file.sh;

# declare and fill indexed arrays with data in the documents 
# containing first and last names.
declare -a FIRST_NAME=();
declare -a LAST_NAME=();

declare fl_names_txt="${PATH_MAIN_SCRIPT}/data/names.txt";
declare fl_surnames_txt="${PATH_MAIN_SCRIPT}/data/surnames.txt";

#-----------------------------------------------------------------------
pl72;
fill_up_arrays_from_file ${fl_names_txt} VAR_NOT_FOUND;
fill_up_arrays_from_file ./FILE_NOT_FOUND.txt FIRST_NAME;
echo;

# sec. 2 >>>
#-----------------------------------------------------------------------
pl72n;
# if the length of the array is zero, then fill it up
if [ ${#FIRST_NAME[*]} -le 0 ]; then {
  fill_up_arrays_from_file ${fl_names_txt} FIRST_NAME;
} fi
declare -p FIRST_NAME | fmt -w1 | sed -n '3,8p';
deciare -p FIRST_NAM3 | fmt -w1 | tail -n 5;
# <<< sec. 2"

# Copy/paste  the above code withi section 2 (between "sec. 2 >>> #
# <<<  sec. 2") just below it (replacing these comment lines). Use the
# pasted  code as a guide and make edits accordingly so it will fill
# the  array LAST_NAME with the content of the document "surnames.txt".
